import React from "react";
import Navbar from "../components/Navbar";
import CourseCards from "../components/CourseCards";

const CoursesPage = () => {
  return (
    <>
      <CourseCards />
    </>
  );
};

export default CoursesPage;
